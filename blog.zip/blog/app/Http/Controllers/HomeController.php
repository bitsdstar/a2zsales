<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB; 
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	 
	 
    public function index()
    {
		$id = auth()->user()->id;
	
       $users = DB::table('users')
				->where('id',$id)->get();
	  
	   $searchess = DB::table('advertisements')
					->where('user_id',$id);
					$myadv =	$searchess->get();
	   
		return view('home',['users'=>$users,'myadv'=>$myadv]);
		
    }
	
	public function edit($id)
{
	$cities = DB::table('cities')->get();
		$categories = DB::table('categories')->get();
		
		$data = DB::table('advertisements')->get()
					->where('id',$id);
	
	
	
	
	
    return view('editproduct',['cities' => $cities, 'categories' => $categories, 'data' => $data]);
}
	
}
