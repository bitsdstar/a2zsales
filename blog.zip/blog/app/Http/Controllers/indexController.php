<?php

namespace App\Http\Controllers;
use Validator;
use Illuminate\Http\Request;
use DB;

class indexController extends Controller
{
     public function index()
    {
		$cities = DB::table('cities')->get();
		$categories = DB::table('categories')->get();
		
		$searches = DB::table('advertisements')->get();
		
        return view('index',['cities' => $cities, 'categories' => $categories, 'searches' => $searches]);
    }
	
	public function search(Request $request)
    {
			 $city = $request->input('city');	
			 $category = $request->input('categories');	
			 $brand = $request->input('brand');	
			 $pricefrom = $request->input('pricefrom');	
			 $priceto = $request->input('priceto');	
		
		
		
			$cities = DB::table('cities')->get();
			$categories = DB::table('categories')->get();
			
			$searchess = DB::table('advertisements')
					->orderBy('price', 'DESC');
				if (isset($city)) {
						$searchess->where('city', $city);
				}
				if (isset($category)) {
					$searchess->where('categories',$category);
				}
				if (isset($brand)) {
					$searchess->where('brand',$brand);
				}
				if (isset($pricefrom) && isset($priceto)) {
						$searchess->whereBetween('price', [$pricefrom, $priceto]);
					}
					$searches =	$searchess->get();
						
						return view('index',['cities' => $cities, 'categories' => $categories,'searches' => $searches]);
			
		
    }
	
	
	
	
	
	
	public function myformAjax($id)
    {
		
        $brand = DB::table('brands')
		
		
                    ->where('cat_name',$id)
                    ->pluck('brand_name','id');
					//die();
		
        return json_encode($brand);
    }
}
