<?php
namespace App\Http\Controllers;

use Validator;
use App\providers\ListsWorkAround;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Advertisement;
use DB;
use Auth;



class newAdvController extends Controller
{
    public function create()
    {
		$cities = DB::table('cities')->get();
		$categories = DB::table('categories')->get();
		
        return view('newadv',['cities' => $cities, 'categories' => $categories]);
    }
	
	public function store(Request $request)
    {
		$validator = Validator::make($request->all(), [
			'city'    => 'required',
			'categories'   => 'required',
			'brand'     => 'required',
			'product_title'     => 'required',
			'product_description'     => 'required',
			'price'     => 'required',
			'address'     => 'required',
			'phone'     => 'required',
			//'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
			'filename' => 'required',
            'filename.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
		]);
	
		if($validator->fails()) {
				return redirect()->route('create')->withErrors($validator)->withInput();
		}
			$username = $request->input('user_name');
			$city = $request->input('city');	
			$category = $request->input('categories');	
			$brand = $request->input('brand');
			$product_title = $request->input('product_title');
			$product_description = $request->input('product_description');
			$price = $request->input('price');
			$address = $request->input('address');
			$phone = $request->input('phone');			
			
			 if($request->hasfile('filename'))
         {

            foreach($request->file('filename') as $image)
            {
                $name=$image->getClientOriginalName();
                $image->move(public_path().'/images/', $name);  
                $data[] = 'images/'.$name;  
            }
         }
		 $id = auth()->user()->id;
		$file = implode(',',$data);
		$insert = array( 'user_id'=>$id, 'user_name'=>$username, 'city'=>$city , 'categories'=>$category, 'brand'=>$brand, 
						'product_title'=>$product_title,'product_description'=>$product_description, 'price'=>$price, 
						'address'=>$address, 'phone'=>$phone, 'image' => $file); 

			DB::table('advertisements')->insert($insert);

			
			return redirect()->back()->with('message', 'Your Advertisement has been submitted.');
 
    }
	
	public function myformAjax($id)
    {
		$brand = DB::table('brands')
					->where('cat_name',$id)
                    ->pluck('brand_name','id');
		
        return json_encode($brand);
    }
}
