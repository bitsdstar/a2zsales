<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class profileViewController extends Controller
{
    public function index(){
$users = DB::select('select * from users');
return view('home',['users'=>$users]);
}
}
