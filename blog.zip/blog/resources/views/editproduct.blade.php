@extends('layouts.app')

@section('content')

<div class="container">
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
    <div class="row justify-content-center">
	
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> <b>Edit Your Advertisement</b></div>
				

                <div class="card-body">
                   @push('css')
						<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
						
					@endpush
					
					<div class="row">   	
						<div class="col-md-12">
		
						
						
						{!! Form::open(['route' => 'store','files' => 'true']) !!}
						
						{!! Form::hidden(' user_name', Auth::user()->name, ['class' => 'form-control']) !!}
						
						@foreach($data as $data1)
						
						
						
						<div class="form-group">
						  {!! Form::label('product title', 'Product Title') !!}
						  {!! Form::text('product_title', $value = $data1->product_title, ['class' => 'form-control']) !!}
						 
							 
						</div>
						
						<div class="form-group">
						  {!! Form::label('product description', 'Product Description') !!}
						  {!! Form::textarea('product_description', $value = $data1->product_description, ['class' => 'form-control']) !!}
							 
						</div>
						
						<div class="form-group">
						  {!! Form::label('price', 'Price') !!}
						  {!! Form::number('price', $value = $data1->price, ['class' => 'form-control']) !!}
							 
						</div>
						
						<div class="form-group">
						  {!! Form::label('address', 'Address') !!}
						  {!! Form::textarea('address', $value = $data1->address, ['class' => 'form-control']) !!}
							 
						</div>
						
						<div class="form-group">
						  {!! Form::label('phone', 'Phone Number') !!}
						  {!! Form::number('phone', $value = $data1->phone, ['class' => 'form-control']) !!}
							 
						</div>
						
						
						
						</br>
						<!--<div class="form-group">
						  {!! Form::file('image', array('class' => 'form-control')) !!}
							 
						</div>-->
						
						@endforeach
						{!! Form::submit('Submit', ['class' => 'btn btn-info']) !!}
   

   

			{!! Form::close() !!}
						
							
							
						</div>
					</div>        
				</div>
				@push('js')
				
				<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
				
				<script type="text/javascript">


    $(document).ready(function() {

      $(".btn-success").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>
				
				
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
				<script type="text/javascript">
    $(document).ready(function() {
        $('select[name="categories"]').on('change', function() {
            var catID = $(this).val();
		var CSRF_TOKEN = '{{csrf_token()}}';
			 var data  = {
            _token:$(this).data('token'),
           
        }
		
            if(catID) {
				
                $.ajax({
					
                    url: '/myform/ajax/'+catID,
                    type: 'GET',
                    dataType: "json",
					//beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#categories").attr('content'));},
					data: {_token: CSRF_TOKEN },
                    success:function(data) {
						
                        
                        $('select[name="brand"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="brand"]').append('<option value="'+ value +'">'+ value +'</option>');
                        });


                    }
                });
            }else{
                $('select[name="brand"]').empty();
            }
        });
    });
</script>
				
				@endpush
            </div>
        </div>
    </div>
</div>

@endsection