@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
			 @push('css')
						<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
						<script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
						<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
					
					@endpush
                <div class="card-header"><b>Your Profile</b> <a class="adv" style="padding-left: 400px;" href="{{ url('/newadv') }}">
                    Submit Your Advertisement
                </a></div>
				
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
					
					<div class="col-md-6">
					  
					
					@foreach ($users as $user)
					
					<b>	Name: {{ $user->name }} </b></br>
					<b>Email: {{ $user->email }}</b>
						

						
						@endforeach
					</div>
					
				
					
					
                </div>
				
					@foreach ($myadv as $search)
				
				<?php  $img =  $search->image;   
				$array = explode(',', $img);
				?>
				
				<div class="container">
				<div class="row">
				<div class="col-sm-12" style="padding-top: 40px;">
				<div class="col-sm-3">  <img width="120" height="80" src="{{ $array[0] }}" alt="nopic"></div>
				<div class="col-sm-3"> <h4> {{ $search->product_title}} </h4></div>
				<div class="col-sm-2"> <button type="button" class="form-control"><a href="{{ url('editproduct/'.$search->id) }}">Edit </a></button></div>
				<div class="col-sm-2"> <button type="button" class="form-control"><a href="{{ url('editproduct/'.$search->id) }}">Delete </a></button></div>
				<div class="col-sm-2"> <button type="button" class="form-control"><a href="{{ url('editproduct/'.$search->id) }}">View </a></button></div>
				</div>
				</div>
				</div>
				
				
				@endforeach
            </div>
        </div>
    </div>
</div>
@endsection
