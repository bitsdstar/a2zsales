@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>Your Profile</b> <a class="adv" style="padding-left: 400px;" href="{{ url('/newadv') }}">
                    Submit Your Advertisement
                </a></div>
				
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
					
					<div class="col-md-6">
					  
					
					@foreach ($users as $user)
					
					<b>	Name: {{ $user->name }} </b></br>
					<b>Email: {{ $user->email }}</b>
						

						
						@endforeach
					</div>
					
					
					
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
