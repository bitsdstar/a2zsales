@extends('layouts.app')

@section('content')
<div class="top-head">
<img src="{{URL::asset('/images/london.jpg')}}" alt="profile Pic" style="    width: -webkit-fill-available;"/>
</div>
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-12" style="padding-top: 10px;">
            <div class="card">
                <div class="card-header"> <b> Search Your Product</b></div>
				

                <div class="card-body">
                   @push('css')
						<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
						<script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
						<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
					
					@endpush
					
					<div class="row">   	
						<div class="col-md-12" >
						{!! Form::open(['route' => 'search','files' => 'true']) !!}
							<div class="col-md-2">
								{!! Form::label('city','Select Your City') !!}
								<select name="city" id="city" class="form-control">
								<option value="">--Select City--</option>
										@foreach($cities as $item)
										
											<option value="{{ $item->city_name }}">{{ $item->city_name }}</option>
										@endforeach
								</select>
							
							</div>    
							<div class="col-md-2">
								{!! Form::label('productcat', 'Browse Category') !!}
								<select name="categories" id="categories" data-token="{{ csrf_token() }}" class="form-control">
									<option value="">--Select Category--</option>
									@foreach($categories as $cat)
										<option value="{{ $cat->cat_name }}">{{ $cat->cat_name }}</option>
									@endforeach
								</select>
							</div>
							
							
							<div class="col-md-2">
								{!! Form::label('brand', 'Brand Name') !!}
								<select name="brand" id="brand" class="form-control">
							 
								</select> 
							</div>
							
								
							<div class="col-md-2">
						  {!! Form::label('pricefrom', 'Price From') !!}
						  <select name="pricefrom" id="pricefrom" data-token="{{ csrf_token() }}" class="form-control">
										<option value="">--Price From--</option>
										<option value="1000">1000</option>
										<option value="5000">5000</option>
										<option value="10000">10000</option>
										<option value="25000">25000</option>
										<option value="50000">50000</option>
										<option value="100000">100000</option>
										<option value="500000">500000</option>
										<option value="1000000">1000000</option>
										<option value="5000000">5000000</option>
										<option value="10000000">10000000</option>
								
								</select>
							 
						</div> 
						
						<div class="col-md-2">
						  {!! Form::label('priceto', 'Price To') !!}
						 <select name="priceto" id="priceto" data-token="{{ csrf_token() }}" class="form-control">
										<option value="">--Price To--</option>
										<option value="1000">1000</option>
										<option value="5000">5000</option>
										<option value="10000">10000</option>
										<option value="25000">25000</option>
										<option value="50000">50000</option>
										<option value="100000">100000</option>
										<option value="500000">500000</option>
										<option value="1000000">1000000</option>
										<option value="5000000">5000000</option>
										<option value="10000000">10000000</option>
										
								
								</select>
							 
						</div>
						
						
							<div class="col-md-2" style="margin-top: 25px;">
								{!! Form::submit('Search', ['class' => 'btn btn-info']) !!} 
							</div>
							
							
							
							{!! Form::close() !!}
						</div>
						
							@push('js')
							<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
							<script type="text/javascript">
								$(document).ready(function() {
								$('select[name="categories"]').on('change', function() {
									var catID = $(this).val();
								var CSRF_TOKEN = '{{csrf_token()}}';
									 var data  = {
									_token:$(this).data('token'),
								   
								}
					
								if(catID) {
									
									$.ajax({
										
										url: '/indexmyform/ajax/'+catID,
										type: 'GET',
										dataType: "json",
										//beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#categories").attr('content'));},
										data: {_token: CSRF_TOKEN },
										success:function(data) {
											
											
											$('select[name="brand"]').empty();
											$.each(data, function(key, value) {
												$('select[name="brand"]').append('<option value="'+ value +'">'+ value +'</option>');
											});


										}
										});
									}else{
										$('select[name="brand"]').empty();
									}
								});
							});
							</script>
				
						@endpush
						
					</div>

				@foreach($searches as $search)
				
				<?php  $img =  $search->image;   
				$array = explode(',', $img);
				?>
				
				<div class="container">
				<div class="row">
				<div class="col-sm-12" style="padding-top: 40px;">
				<div class="col-sm-3">  <img width="150" height="100" src="{{ $array[0] }}" alt="nopic"></div>
				<div class="col-sm-6"> <h3> {{ $search->product_title}} </h3><h4>{{ $search->product_description}}</h4>
				<h5>Mobile: {{ $search->phone }}</h5>
				</div>
				<div class="col-sm-3"><h3>{{ $search->price }} </h3> </div>
				</div>
				</div>
				</div>
				
				
				@endforeach
					
				</div>
            </div>
        </div>
    </div>
</div>

@endsection