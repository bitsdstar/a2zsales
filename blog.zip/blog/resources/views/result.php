@extends('layouts.app')

@section('content')

<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> <b>Submit Your Advertisement</b></div>
				

                <div class="card-body">
                   @push('css')
						<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
						
					@endpush
					
					<div class="row">   	
						<div class="col-md-12">
		
						
						
						{!! Form::open(['route' => 'store']) !!}
						
						 <div class="form-group">
							{!! Form::label('city','City') !!}
							<select name="city" id="city" class="form-control">
									@foreach($cities as $item)
										<option value="{{ $item->id }}">{{ $item->city_name }}</option>
									@endforeach
							</select>
						</div>

						<div class="form-group">
						  {!! Form::label('productcat', 'Product Category') !!}
						  <select name="categories" id="categories" data-token="{{ csrf_token() }}" class="form-control">
							  @foreach($categories as $cat)
								<option value="{{ $cat->id }}">{{ $cat->cat_name }}</option>
							  @endforeach
							</select>
						</div>
						
						<div class="form-group">
						  {!! Form::label('brand', 'Brand') !!}
						  <select name="brand" id="brand" class="form-control">
							 
							</select>
						</div>
						
						<div class="form-group">
						  {!! Form::label('product title', 'Product Title') !!}
						  {!! Form::text('product_title', null, ['class' => 'form-control']) !!}
							 
						</div>
						
						<div class="form-group">
						  {!! Form::label('product description', 'Product Description') !!}
						  {!! Form::textarea('product_description', null, ['class' => 'form-control']) !!}
							 
						</div>
						
						<div class="form-group">
						  {!! Form::label('address', 'Address') !!}
						  {!! Form::textarea('address', null, ['class' => 'form-control']) !!}
							 
						</div>
						
						<?php
							// echo Form::open(array('url' => '/uploadfile','files'=>'true'));
							// echo 'Select the file to upload.';
							// echo Form::file('image');
							 //echo Form::submit('Upload File');
							 //echo Form::close();
						?>

						{!! Form::submit('Submit', ['class' => 'btn btn-info']) !!}
   

   

  {!! Form::close() !!}
						
							
							
						</div>
					</div>        
				</div>
				@push('js')
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
				<script type="text/javascript">
    $(document).ready(function() {
        $('select[name="categories"]').on('change', function() {
            var catID = $(this).val();
		var CSRF_TOKEN = '{{csrf_token()}}';
			 var data  = {
            _token:$(this).data('token'),
           
        }
		
            if(catID) {
				
                $.ajax({
					
                    url: '/myform/ajax/'+catID,
                    type: 'GET',
                    dataType: "json",
					//beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#categories").attr('content'));},
					data: {_token: CSRF_TOKEN },
                    success:function(data) {
						
                        
                        $('select[name="brand"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="brand"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });


                    }
                });
            }else{
                $('select[name="brand"]').empty();
            }
        });
    });
</script>
				
				@endpush
            </div>
        </div>
    </div>
</div>

@endsection