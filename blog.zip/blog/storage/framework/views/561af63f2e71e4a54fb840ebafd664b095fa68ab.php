<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
			 <?php $__env->startPush('css'); ?>
						<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
						<script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
						<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
					
					<?php $__env->stopPush(); ?>
                <div class="card-header"><b>Your Profile</b> <a class="adv" style="padding-left: 400px;" href="<?php echo e(url('/newadv')); ?>">
                    Submit Your Advertisement
                </a></div>
				
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
					
					<div class="col-md-6">
					  
					
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<b>	Name: <?php echo e($user->name); ?> </b></br>
					<b>Email: <?php echo e($user->email); ?></b>
						

						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					
				
					
					
                </div>
				
					<?php $__currentLoopData = $myadv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
				<?php  $img =  $search->image;   
				$array = explode(',', $img);
				?>
				
				<div class="container">
				<div class="row">
				<div class="col-sm-12" style="padding-top: 40px;">
				<div class="col-sm-3">  <img width="120" height="80" src="<?php echo e($array[0]); ?>" alt="nopic"></div>
				<div class="col-sm-3"> <h4> <?php echo e($search->product_title); ?> </h4></div>
				<div class="col-sm-2"> <button type="button" class="form-control"><a href="<?php echo e(url('editproduct/'.$search->id)); ?>">Edit </a></button></div>
				<div class="col-sm-2"> <button type="button" class="form-control"><a href="<?php echo e(url('editproduct/'.$search->id)); ?>">Delete </a></button></div>
				<div class="col-sm-2"> <button type="button" class="form-control"><a href="<?php echo e(url('editproduct/'.$search->id)); ?>">View </a></button></div>
				</div>
				</div>
				</div>
				
				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>