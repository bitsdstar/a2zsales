<?php $__env->startSection('content'); ?>
<div class="top-head">
<img src="<?php echo e(URL::asset('/images/london.jpg')); ?>" alt="profile Pic" style="    width: -webkit-fill-available;"/>
</div>
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-12" style="padding-top: 10px;">
            <div class="card">
                <div class="card-header"> <b> Search Your Product</b></div>
				

                <div class="card-body">
                   <?php $__env->startPush('css'); ?>
						<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
						<script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
						<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
					
					<?php $__env->stopPush(); ?>
					
					<div class="row">   	
						<div class="col-md-12" >
						<?php echo Form::open(['route' => 'search','files' => 'true']); ?>

							<div class="col-md-2">
								<?php echo Form::label('city','Select Your City'); ?>

								<select name="city" id="city" class="form-control">
								<option value="">--Select City--</option>
										<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
											<option value="<?php echo e($item->city_name); ?>"><?php echo e($item->city_name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							
							</div>    
							<div class="col-md-2">
								<?php echo Form::label('productcat', 'Browse Category'); ?>

								<select name="categories" id="categories" data-token="<?php echo e(csrf_token()); ?>" class="form-control">
									<option value="">--Select Category--</option>
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($cat->cat_name); ?>"><?php echo e($cat->cat_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							
							
							<div class="col-md-2">
								<?php echo Form::label('brand', 'Brand Name'); ?>

								<select name="brand" id="brand" class="form-control">
							 
								</select> 
							</div>
							
								
							<div class="col-md-2">
						  <?php echo Form::label('pricefrom', 'Price From'); ?>

						  <select name="pricefrom" id="pricefrom" data-token="<?php echo e(csrf_token()); ?>" class="form-control">
										<option value="">--Price From--</option>
										<option value="1000">1000</option>
										<option value="5000">5000</option>
										<option value="10000">10000</option>
										<option value="25000">25000</option>
										<option value="50000">50000</option>
										<option value="100000">100000</option>
										<option value="500000">500000</option>
										<option value="1000000">1000000</option>
										<option value="5000000">5000000</option>
										<option value="10000000">10000000</option>
								
								</select>
							 
						</div> 
						
						<div class="col-md-2">
						  <?php echo Form::label('priceto', 'Price To'); ?>

						 <select name="priceto" id="priceto" data-token="<?php echo e(csrf_token()); ?>" class="form-control">
										<option value="">--Price To--</option>
										<option value="1000">1000</option>
										<option value="5000">5000</option>
										<option value="10000">10000</option>
										<option value="25000">25000</option>
										<option value="50000">50000</option>
										<option value="100000">100000</option>
										<option value="500000">500000</option>
										<option value="1000000">1000000</option>
										<option value="5000000">5000000</option>
										<option value="10000000">10000000</option>
										
								
								</select>
							 
						</div>
						
						
							<div class="col-md-2" style="margin-top: 25px;">
								<?php echo Form::submit('Search', ['class' => 'btn btn-info']); ?> 
							</div>
							
							
							
							<?php echo Form::close(); ?>

						</div>
						
							<?php $__env->startPush('js'); ?>
							<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
							<script type="text/javascript">
								$(document).ready(function() {
								$('select[name="categories"]').on('change', function() {
									var catID = $(this).val();
								var CSRF_TOKEN = '<?php echo e(csrf_token()); ?>';
									 var data  = {
									_token:$(this).data('token'),
								   
								}
					
								if(catID) {
									
									$.ajax({
										
										url: '/indexmyform/ajax/'+catID,
										type: 'GET',
										dataType: "json",
										//beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#categories").attr('content'));},
										data: {_token: CSRF_TOKEN },
										success:function(data) {
											
											
											$('select[name="brand"]').empty();
											$.each(data, function(key, value) {
												$('select[name="brand"]').append('<option value="'+ value +'">'+ value +'</option>');
											});


										}
										});
									}else{
										$('select[name="brand"]').empty();
									}
								});
							});
							</script>
				
						<?php $__env->stopPush(); ?>
						
					</div>

				<?php $__currentLoopData = $searches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
				<?php  $img =  $search->image;   
				$array = explode(',', $img);
				?>
				
				<div class="container">
				<div class="row">
				<div class="col-sm-12" style="padding-top: 40px;">
				<div class="col-sm-3">  <img width="150" height="100" src="<?php echo e($array[0]); ?>" alt="nopic"></div>
				<div class="col-sm-6"> <h3> <?php echo e($search->product_title); ?> </h3><h4><?php echo e($search->product_description); ?></h4>
				<h5>Mobile: <?php echo e($search->phone); ?></h5>
				</div>
				<div class="col-sm-3"><h3><?php echo e($search->price); ?> </h3> </div>
				</div>
				</div>
				</div>
				
				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>