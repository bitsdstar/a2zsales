<?php $__env->startSection('content'); ?>

<div class="container">
<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
    <div class="row justify-content-center">
	
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> <b>Edit Your Advertisement</b></div>
				

                <div class="card-body">
                   <?php $__env->startPush('css'); ?>
						<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
						
					<?php $__env->stopPush(); ?>
					
					<div class="row">   	
						<div class="col-md-12">
		
						
						
						<?php echo Form::open(['route' => 'store','files' => 'true']); ?>

						
						<?php echo Form::hidden(' user_name', Auth::user()->name, ['class' => 'form-control']); ?>

						
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
						
						
						<div class="form-group">
						  <?php echo Form::label('product title', 'Product Title'); ?>

						  <?php echo Form::text('product_title', $value = $data1->product_title, ['class' => 'form-control']); ?>

						 
							 
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('product description', 'Product Description'); ?>

						  <?php echo Form::textarea('product_description', $value = $data1->product_description, ['class' => 'form-control']); ?>

							 
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('price', 'Price'); ?>

						  <?php echo Form::number('price', $value = $data1->price, ['class' => 'form-control']); ?>

							 
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('address', 'Address'); ?>

						  <?php echo Form::textarea('address', $value = $data1->address, ['class' => 'form-control']); ?>

							 
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('phone', 'Phone Number'); ?>

						  <?php echo Form::number('phone', $value = $data1->phone, ['class' => 'form-control']); ?>

							 
						</div>
						
						
						
						</br>
						<!--<div class="form-group">
						  <?php echo Form::file('image', array('class' => 'form-control')); ?>

							 
						</div>-->
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php echo Form::submit('Submit', ['class' => 'btn btn-info']); ?>

   

   

			<?php echo Form::close(); ?>

						
							
							
						</div>
					</div>        
				</div>
				<?php $__env->startPush('js'); ?>
				
				<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
				
				<script type="text/javascript">


    $(document).ready(function() {

      $(".btn-success").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>
				
				
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
				<script type="text/javascript">
    $(document).ready(function() {
        $('select[name="categories"]').on('change', function() {
            var catID = $(this).val();
		var CSRF_TOKEN = '<?php echo e(csrf_token()); ?>';
			 var data  = {
            _token:$(this).data('token'),
           
        }
		
            if(catID) {
				
                $.ajax({
					
                    url: '/myform/ajax/'+catID,
                    type: 'GET',
                    dataType: "json",
					//beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#categories").attr('content'));},
					data: {_token: CSRF_TOKEN },
                    success:function(data) {
						
                        
                        $('select[name="brand"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="brand"]').append('<option value="'+ value +'">'+ value +'</option>');
                        });


                    }
                });
            }else{
                $('select[name="brand"]').empty();
            }
        });
    });
</script>
				
				<?php $__env->stopPush(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>