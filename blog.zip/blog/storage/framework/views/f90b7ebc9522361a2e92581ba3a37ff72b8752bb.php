<?php $__env->startSection('content'); ?>

<div class="container">
<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
    <div class="row justify-content-center">
	
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> <b>Submit Your Advertisement</b></div>
				

                <div class="card-body">
                   <?php $__env->startPush('css'); ?>
						<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
						
					<?php $__env->stopPush(); ?>
					
					<div class="row">   	
						<div class="col-md-12">
		
						
						
						<?php echo Form::open(['route' => 'store','files' => 'true']); ?>

						
						<?php echo Form::hidden(' user_name', Auth::user()->name, ['class' => 'form-control']); ?>

						
						 <div class="form-group">
							<?php echo Form::label('city','City'); ?>

							<select name="city" id="city" class="form-control">
									<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($item->city_name); ?>"><?php echo e($item->city_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group">
						  <?php echo Form::label('productcat', 'Product Category'); ?>

						  <select name="categories" id="categories" data-token="<?php echo e(csrf_token()); ?>" class="form-control">
							  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($cat->cat_name); ?>"><?php echo e($cat->cat_name); ?></option>
							  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('brand', 'Brand'); ?>

						  <select name="brand" id="brand" class="form-control">
							 
							</select>
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('product title', 'Product Title'); ?>

						  <?php echo Form::text('product_title', null, ['class' => 'form-control']); ?>

							 
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('product description', 'Product Description'); ?>

						  <?php echo Form::textarea('product_description', null, ['class' => 'form-control']); ?>

							 
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('price', 'Price'); ?>

						  <?php echo Form::number('price', null, ['class' => 'form-control']); ?>

							 
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('address', 'Address'); ?>

						  <?php echo Form::textarea('address', null, ['class' => 'form-control']); ?>

							 
						</div>
						
						<div class="form-group">
						  <?php echo Form::label('phone', 'Phone Number'); ?>

						  <?php echo Form::number('phone', null, ['class' => 'form-control']); ?>

							 
						</div>
						
						
						<div class="input-group control-group increment" >
						  <input type="file" name="filename[]" class="form-control">
						  <div class="input-group-btn"> 
							<button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
						  </div>
						</div>
						<div class="clone hide">
						  <div class="control-group input-group" style="margin-top:10px">
							<input type="file" name="filename[]" class="form-control">
							<div class="input-group-btn"> 
							  <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
							</div>
						  </div>
						</div>
						</br>
						<!--<div class="form-group">
						  <?php echo Form::file('image', array('class' => 'form-control')); ?>

							 
						</div>-->

						<?php echo Form::submit('Submit', ['class' => 'btn btn-info']); ?>

   

   

			<?php echo Form::close(); ?>

						
							
							
						</div>
					</div>        
				</div>
				<?php $__env->startPush('js'); ?>
				
				<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
				
				<script type="text/javascript">


    $(document).ready(function() {

      $(".btn-success").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>
				
				
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
				<script type="text/javascript">
    $(document).ready(function() {
        $('select[name="categories"]').on('change', function() {
            var catID = $(this).val();
		var CSRF_TOKEN = '<?php echo e(csrf_token()); ?>';
			 var data  = {
            _token:$(this).data('token'),
           
        }
		
            if(catID) {
				
                $.ajax({
					
                    url: '/myform/ajax/'+catID,
                    type: 'GET',
                    dataType: "json",
					//beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#categories").attr('content'));},
					data: {_token: CSRF_TOKEN },
                    success:function(data) {
						
                        
                        $('select[name="brand"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="brand"]').append('<option value="'+ value +'">'+ value +'</option>');
                        });


                    }
                });
            }else{
                $('select[name="brand"]').empty();
            }
        });
    });
</script>
				
				<?php $__env->stopPush(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>